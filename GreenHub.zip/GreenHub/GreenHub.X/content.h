#ifndef CONTENT_H
#define	CONTENT_H

#include "glcd.h"

extern unsigned char const home_display[1024];
extern unsigned char const menu_display[1024];
extern unsigned char const vrata_disp_manual[1024];
extern unsigned char const vrata_disp_auto_open[1024];
extern unsigned char const vrata_disp_auto_closed[1024];
extern unsigned char const co2_display[1024];
extern unsigned char const light_display[1024];
extern unsigned char perc_bar[1024];

#endif	/* CONTENT_H */

